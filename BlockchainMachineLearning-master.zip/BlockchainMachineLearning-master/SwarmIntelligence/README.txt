Swarm Intelligence for Routing in Communication Networks
